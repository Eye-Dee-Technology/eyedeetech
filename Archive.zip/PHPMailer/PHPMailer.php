<?php

namespace PHPMailer\PHPMailer;

class PHPMailer
{
    public $host = '';
    public $port = 587;
    public $encryption = 'tls';
    public $username = '';
    public $password = '';
    public $from = '';
    public $fromName = '';
    public $replyTo = [];
    public $to = [];
    public $subject = '';
    public $body = '';
    public $isHTML = false;
    public $addEmbeddedImage = [];
    public $attachments = [];
    public $connection;
    public $timeout = 15;
    public $debug = false;

    const ENCRYPTION_STARTTLS = 'tls';
    const ENCRYPTION_SMTPS = 'ssl';

    public function __construct()
    {
    }

    public function addAddress($address, $name = '')
    {
        $this->to[] = ['address' => $address, 'name' => $name];
    }

    public function addReplyTo($address, $name = '')
    {
        $this->replyTo[] = ['address' => $address, 'name' => $name];
    }

    public function addAttachment($path, $name = '')
    {
        if (file_exists($path)) {
            $this->attachments[] = ['path' => $path, 'name' => $name ?: basename($path)];
        }
    }

    public function send()
    {
        try {
            $this->connect();
            return true;
        } catch (Exception $e) {
            error_log("PHPMailer Error: " . $e->getMessage());
            return false;
        }
    }

    private function connect()
    {
        $context = stream_context_create();
        
        if ($this->encryption === self::ENCRYPTION_SMTPS) {
            stream_context_set_option($context, 'ssl', 'allow_self_signed', true);
            stream_context_set_option($context, 'ssl', 'verify_peer', false);
            $protocol = 'ssl://';
        } else {
            $protocol = 'tcp://';
        }

        $this->connection = @stream_socket_client(
            $protocol . $this->host . ':' . $this->port,
            $errno,
            $errstr,
            $this->timeout,
            STREAM_CLIENT_CONNECT,
            $context
        );

        if (!$this->connection) {
            throw new Exception("Could not connect to SMTP host: $errstr ($errno)");
        }

        $response = $this->getResponse();
        if (substr($response, 0, 3) !== '220') {
            throw new Exception("Unexpected server response: $response");
        }

        $this->sendCommand('EHLO ' . gethostname());

        if ($this->encryption === self::ENCRYPTION_STARTTLS) {
            $this->sendCommand('STARTTLS');
            stream_socket_enable_crypto($this->connection, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            $this->sendCommand('EHLO ' . gethostname());
        }

        $this->authenticate();
        $this->sendMail();
        
        $this->sendCommand('QUIT');
        @fclose($this->connection);
    }

    private function authenticate()
    {
        $this->sendCommand('AUTH LOGIN');
        $this->sendCommand(base64_encode($this->username));
        $response = $this->getResponse();
        if (substr($response, 0, 3) !== '334') {
            throw new Exception("AUTH failed");
        }
        
        $this->sendCommand(base64_encode($this->password));
        $response = $this->getResponse();
        if (substr($response, 0, 3) !== '235') {
            throw new Exception("Authentication failed");
        }
    }

    private function sendMail()
    {
        $from = $this->from ?: $this->username;
        $this->sendCommand("MAIL FROM:<$from>");
        
        foreach ($this->to as $recipient) {
            $this->sendCommand("RCPT TO:<{$recipient['address']}>");
        }

        $this->sendCommand('DATA');

        $headers = "From: " . ($this->fromName ? "{$this->fromName} <$from>" : $from) . "\r\n";
        
        if (!empty($this->replyTo)) {
            $headers .= "Reply-To: " . $this->replyTo[0]['address'] . "\r\n";
        }

        foreach ($this->to as $recipient) {
            if ($recipient['name']) {
                $headers .= "To: {$recipient['name']} <{$recipient['address']}>\r\n";
            } else {
                $headers .= "To: {$recipient['address']}\r\n";
            }
        }

        $headers .= "Subject: " . $this->encodeHeader($this->subject) . "\r\n";
        $headers .= "MIME-Version: 1.0\r\n";

        $boundary = md5(time());
        
        if (!empty($this->attachments)) {
            $headers .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n\r\n";
            $body = "--$boundary\r\n";
            $body .= "Content-Type: text/plain; charset=UTF-8\r\n";
            $body .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
            $body .= $this->body . "\r\n\r\n";

            foreach ($this->attachments as $attachment) {
                $file_content = file_get_contents($attachment['path']);
                $file_encoded = chunk_split(base64_encode($file_content));
                
                $body .= "--$boundary\r\n";
                $body .= "Content-Type: application/octet-stream; name=\"{$attachment['name']}\"\r\n";
                $body .= "Content-Disposition: attachment; filename=\"{$attachment['name']}\"\r\n";
                $body .= "Content-Transfer-Encoding: base64\r\n\r\n";
                $body .= $file_encoded . "\r\n";
            }
            $body .= "--$boundary--\r\n";
        } else {
            $headers .= "Content-Type: text/plain; charset=UTF-8\r\n\r\n";
            $body = $this->body;
        }

        fwrite($this->connection, $headers . $body . "\r\n.\r\n");
        $response = $this->getResponse();
        if (substr($response, 0, 3) !== '250') {
            throw new Exception("Failed to send message: $response");
        }
    }

    private function sendCommand($command)
    {
        fwrite($this->connection, $command . "\r\n");
        return $this->getResponse();
    }

    private function getResponse()
    {
        $response = '';
        while ($line = fgets($this->connection, 1024)) {
            $response .= $line;
            if (substr($line, 3, 1) === ' ') {
                break;
            }
        }
        return $response;
    }

    private function encodeHeader($str)
    {
        if (!preg_match('/[\x80-\xFF]/', $str)) {
            return $str;
        }
        return '=?UTF-8?B?' . base64_encode($str) . '?=';
    }
}
