<?php

namespace PHPMailer\PHPMailer;

class SMTP
{
    public $host;
    public $port = 25;
    public $username;
    public $password;
    public $encryption;
    public $timeout = 15;
    public $connection;
    public $debug = false;

    public function connect()
    {
        $context = stream_context_create();
        
        if ($this->encryption === 'ssl') {
            stream_context_set_option($context, 'ssl', 'allow_self_signed', true);
            stream_context_set_option($context, 'ssl', 'verify_peer', false);
        }
        
        $this->connection = @stream_socket_client(
            ($this->encryption === 'ssl' ? 'ssl://' : 'tcp://') . $this->host . ':' . $this->port,
            $errno,
            $errstr,
            $this->timeout,
            STREAM_CLIENT_CONNECT,
            $context
        );
        
        if (!$this->connection) {
            throw new Exception("Failed to connect to SMTP server: $errstr");
        }
        
        return $this->getResponse();
    }

    public function getResponse()
    {
        $response = '';
        while ($line = fgets($this->connection, 1024)) {
            $response .= $line;
            if (substr($line, 3, 1) === ' ') {
                break;
            }
        }
        return $response;
    }

    public function sendCommand($command)
    {
        fwrite($this->connection, $command . "\r\n");
        return $this->getResponse();
    }

    public function authenticate()
    {
        $this->sendCommand('EHLO mail.privateemail.com');
        $this->sendCommand('AUTH LOGIN');
        $this->sendCommand(base64_encode($this->username));
        $this->sendCommand(base64_encode($this->password));
    }

    public function close()
    {
        if ($this->connection) {
            @fclose($this->connection);
        }
    }
}
